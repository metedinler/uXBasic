# uXBasic Compiler

uXBasic Compiler, BASIC benzeri sade bir dil ile Windows uzerinde program yazmayi kolaylastirmayi hedefleyen acik kaynak bir compiler dagitim deposudur.

Bu depo ana gelistirme deposunun sade, indirilebilir ve denenebilir surumudur.

Burada sunlar bulunur:

- derlenmis compiler exe
- gerekli kaynak dosyalari
- hazir `.bas` test ve demo dosyalari
- baslangic rehberi
- mimari ve dil dokumani
- test sonuc raporu

## Kimler icin

Bu depo ozellikle su kisiler icin hazirlandi:

- BASIC ogrenmek isteyenler
- bilgisayar programlamaya yeni baslayanlar
- Windows uzerinde sade bir dil denemek isteyenler
- projeyi sponsor veya is birligi gozuyle incelemek isteyenler

## Bugun ne calisiyor

Bugun pratikte dogrulanan kisimlar:

- lexer + parser
- semantic analiz
- AST/MIR tabanli yorumlayici zinciri
- native x64 asm / object / exe uretimi
- temel komutlar, operatorler ve intrinsic'lerin buyuk bolumu
- JSON AST ve pipeline rapor ciktilari
- FFI disi native console ornekleri

## Bugun ne gelistirme asamasinda

Acik ve durust durum:

- `CALL(DLL)` artik native x64 derleme zincirini kirmiyor
- ilgili `.bas` dosyalari icin asm, object ve exe artefact'lari uretiliyor
- fakat gercek DLL resolver (`LoadLibrary` / `GetProcAddress`) tamamlanmadigi icin bu cagrilar su an kontrollu stub lane uzerinden no-op veya `0` donusune iniyor
- Win32 GUI ve ileri API senaryolari bu nedenle henuz "tam calisiyor" seviyesinde degil

## Nereden baslamali

1. [START_HERE.md](START_HERE.md) dosyasini ac
2. [PCK5.md](PCK5.md) ile dilin komutlarini oku
3. `tests/basicCodeTests/42_uxb_native_console_codegen_smoke.bas` ornegini derle
4. Sonra `31_uxb_windows_kernel_sleep_tick.bas` ile FFI durumunu dene

## Hazir belgeler

- Baslangic rehberi: [START_HERE.md](START_HERE.md)
- Mimari: [uxbasic_mimari.md](uxbasic_mimari.md)
- Dil ve syntax dokumani: [PCK5.md](PCK5.md)
- Sponsor ve vizyon metni: [SPONSORING.md](SPONSORING.md)
- Test ve durum raporu: [tests/basicCodeTests/RESULTS.md](tests/basicCodeTests/RESULTS.md)

## Dizinin yapisi

- `bin/`
  - dagitima konulan compiler executable
- `src/`
  - compiler kaynak kodu
- `tests/basicCodeTests/`
  - `.bas` ornekleri
- `tests/basicCodeTests/out/`
  - AST JSON, pipeline JSON, obj, asm, exe gibi uretilmis artefact'lar

## Hemen dene

Compiler'i yeniden derlemeden var olan binary ile denemek icin PowerShell'de:

```powershell
.\bin\uXBasic.exe .\tests\basicCodeTests\42_uxb_native_console_codegen_smoke.bas --build-x64
```

Yorumlayici denemesi icin:

```powershell
.\bin\uXBasic.exe .\tests\basicCodeTests\42_uxb_native_console_codegen_smoke.bas --execmem
```

## Ana gelistirme deposu

Tum aktif gelistirme, issue takibi ve daha genis dosya agaci icin ana repo:

- [uXBasic](https://github.com/metedinler/uXBasic)

