# uXBasic Compiler Baslangic Rehberi

Bu rehber, bilgisayarda cok deneyimi olmayan birinin bile projeyi acip ilk denemesini yapabilmesi icin yazildi.

## 1. Bu depoda ne var

Burada hazir olarak bulacagin seyler:

- `bin\uXBasic.exe`
- `src\` kaynak kodlari
- `tests\basicCodeTests\` altinda hazir `.bas` programlari
- sonuc raporlari ve JSON artefact'lari

## 2. Ilk acilacak dosyalar

Sirayla sunlari ac:

1. [README.md](README.md)
2. [PCK5.md](PCK5.md)
3. [tests/basicCodeTests/42_uxb_native_console_codegen_smoke.bas](tests/basicCodeTests/42_uxb_native_console_codegen_smoke.bas)

## 3. Windows'ta nasil calistirilir

PowerShell ac ve repo klasorune gel:

```powershell
cd C:\yol\uXBasic-Compiler-repo
```

Sonra yorumlayici ile dene:

```powershell
.\bin\uXBasic.exe .\tests\basicCodeTests\42_uxb_native_console_codegen_smoke.bas --execmem
```

Native x64 exe uretmek icin:

```powershell
.\bin\uXBasic.exe .\tests\basicCodeTests\42_uxb_native_console_codegen_smoke.bas --build-x64
```

Genellikle sonuc burada olusur:

```text
dist\x64build\program.exe
```

## 4. Hangi ornekler bugun daha guvenli

Ilk olarak bunlari dene:

- [42_uxb_native_console_codegen_smoke.bas](tests/basicCodeTests/42_uxb_native_console_codegen_smoke.bas)
- [43_uxb_native_flow_math_codegen_smoke.bas](tests/basicCodeTests/43_uxb_native_flow_math_codegen_smoke.bas)

## 5. DLL ve Windows API denemeleri

Sunlar Windows API ve DLL kullanan orneklerdir:

- [31_uxb_windows_kernel_sleep_tick.bas](tests/basicCodeTests/31_uxb_windows_kernel_sleep_tick.bas)
- [32_uxb_windows_user32_metrics.bas](tests/basicCodeTests/32_uxb_windows_user32_metrics.bas)
- [33_uxb_windows_user32_messagebox_interactive.bas](tests/basicCodeTests/33_uxb_windows_user32_messagebox_interactive.bas)

Onemli not:

- Bu ornekler bugun derlenebilir.
- AST JSON, asm, object ve exe artefact'lari uretilir.
- Ama gercek DLL resolver eksigi nedeniyle runtime sonucu tam Windows API etkisini henuz vermeyebilir.

## 6. Test sonuclarini nerede gorecegim

- Toplu durum raporu: [tests/basicCodeTests/RESULTS.md](tests/basicCodeTests/RESULTS.md)
- Uretilmis ciktilar: [tests/basicCodeTests/out](tests/basicCodeTests/out)

## 7. Proje su an Windows'ta calisiyor mu

Kisa ve durust cevap:

- Evet, compiler Windows uzerinde derleniyor ve calisiyor.
- Evet, native x64 console exe ureten zincir calisiyor.
- Evet, `CALL(DLL)` iceren programlar da artik derlenebiliyor.
- Hayir, tum DLL/API runtime davranisi henuz tamamlanmis degil.
- GUI tarafi deneysel ve gelisiyor.

