# uXBasic Sponsorluk Notu

uXBasic, BASIC'in anlasilirligini modern Windows derleme hedefleriyle birlestirmeyi amaclayan acik kaynak bir compiler projesidir.

## Neden dikkat cekici

- yeni baslayanlar icin dusuk esikli bir dil sunuyor
- egitim, oyun, otomasyon ve arac gelistirme gibi alanlara dokunuyor
- parser, semantic, runtime ve native x64 codegen gibi ciddi compiler katmanlarini gercek kod olarak iceriyor
- somut testler, artefact'lar ve release ureten bir teknik tabana sahip

## Sponsor destegi neyi hizlandirir

- gercek DLL resolver ve FFI runtime tamamlama
- Win32 GUI calisma yolunun olgunlastirilmasi
- paketleme ve kolay kurulum deneyimi
- ogrenciler icin daha iyi dokumantasyon
- ornek uygulama ve video/egitim icerikleri

## Neden simdi

Proje fikir asamasini gecmis durumda. Temel compiler mimarisi, dokumantasyon ve test seti ortada. Bu asamada verilecek destek, projeyi "deneysel ama umut verici" seviyesinden "daha kolay kurulan ve daha cok kullanilan" seviyesine tasiyabilir.
